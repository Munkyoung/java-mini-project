package miniGame.tetris;

public interface BlockStatus {
		int EMPTY = 0;
		int MOVINGBLOCK = 1;
		int STOPPEDBLOCK = 2;
		
		 int PANELHEIGHT = 20;
		 int PANELWIDTH = 10;
}
